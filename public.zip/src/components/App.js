import React from "react"
import Display from "./Display"

export default function Home() {
  return (
    <div>
        <Display/>
    </div>
  )
}
